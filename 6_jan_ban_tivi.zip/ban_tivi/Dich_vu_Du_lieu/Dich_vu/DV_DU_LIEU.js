
var NodeJs_Dich_vu = require("http")
var Luu_tru = require("../Xu_ly/XL_LUU_TRU")
//var Port = 1000
var Port = normalizePort(process.env.PORT || 1000);
var Xu_ly_Tham_so = require('querystring')
var Du_lieu = {}
Du_lieu = Luu_tru.Doc_Du_lieu()
var Goi_thu = require("../Xu_ly/Xu_ly_goi_email")
var Dich_vu = NodeJs_Dich_vu.createServer((Yeu_cau, Dap_ung) => {
  var Chuoi_Nhan = ""
  var Dia_chi_Xu_ly = Yeu_cau.url.replace("/", "")
  Yeu_cau.on('data', (chunk) => { Chuoi_Nhan += chunk })
  Yeu_cau.on('end', () => {

    var Tham_so = Xu_ly_Tham_so.parse(Dia_chi_Xu_ly.replace("?", ""))

    var Ma_so_Xu_ly = Tham_so.Ma_so_Xu_ly
    var Chuoi_Kq = ""
    if (Ma_so_Xu_ly == "Doc_Danh_sach_Dien_thoai") {
      Chuoi_Kq = JSON.stringify(Du_lieu)
      Dap_ung.setHeader("Access-Control-Allow-Origin", '*')
      Dap_ung.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
      Dap_ung.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type');
      Dap_ung.setHeader('Access-Control-Allow-Credentials', true);
      Dap_ung.end(Chuoi_Kq);
    } else if (Ma_so_Xu_ly == "Ghi_Phieu_Dat_hang") {
      var Kq = ""
      var DsPhieu_Dat_hang = JSON.parse(Chuoi_Nhan)

      Dap_ung.setHeader("Access-Control-Allow-Origin", '*')
      Dap_ung.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
      Dap_ung.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type');
      Dap_ung.setHeader('Access-Control-Allow-Credentials', true);
      DsPhieu_Dat_hang.forEach(Phieu => {
        var Dien_thoai = Du_lieu.Danh_sach_Dien_thoai.find(x => x.Ma_so == Phieu.Dien_thoai.Ma_so)
        var So_Phieu_Dat = 1
        if (Dien_thoai.Danh_sach_Phieu_Dat == undefined) {
          Dien_thoai.Danh_sach_Phieu_Dat = []
        }

        So_Phieu_Dat = Dien_thoai.Danh_sach_Phieu_Dat.length + 1
        Phieu.Phieu_Dat.So_Phieu_Dat = So_Phieu_Dat

        Dien_thoai.Danh_sach_Phieu_Dat.push(Phieu.Phieu_Dat)

        Kq = Luu_tru.Cap_nhat_Doi_tuong("Dien_thoai", Dien_thoai)
        if (Kq == "") {
          Chuoi_Kq = "OK"
        } else {
          Dien_thoai.Danh_sach_Phieu_Dat.pop()
          Chuoi_Kq = "Error"
        }
        Dap_ung.end(Chuoi_Kq);
      })


    }else if (Ma_so_Xu_ly == "Goi_thu_Lien_he") {

      var from = "kimtaetae8@gmail.com"
      var to = "kimtaetae8@gmail.com"
      var subject = "Khách hàng Liên hệ "
      var body = Chuoi_Nhan
      var kqPromise = Goi_thu.Goi_Thu_Lien_he(from, to, subject, body)
      console.log(kqPromise)
      kqPromise.then(result => {
        console.log(result)
        Chuoi_Kq = "OK"
        Dap_ung.setHeader("Access-Control-Allow-Origin", '*')
        Dap_ung.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
        Dap_ung.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type');
        Dap_ung.setHeader('Access-Control-Allow-Credentials', true);
        Dap_ung.end(Chuoi_Kq);
      }).catch(Loi=>{
        Chuoi_Kq = "ERROR"
        console.log(Loi)
        Dap_ung.setHeader("Access-Control-Allow-Origin", '*')
        Dap_ung.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
        Dap_ung.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type');
        Dap_ung.setHeader('Access-Control-Allow-Credentials', true);
        Dap_ung.end(Chuoi_Kq);
      })

    }    
     else {
      Chuoi_Kq = Luu_tru.Doc_Thong_tin_Dich_vu()
      Dap_ung.setHeader("Access-Control-Allow-Origin", '*')
      Dap_ung.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
      Dap_ung.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type');
      Dap_ung.setHeader('Access-Control-Allow-Credentials', true);
      Dap_ung.end(Chuoi_Kq);
    }
  })
})

Dich_vu.listen(Port,
  console.log(`Dịch vụ Dữ liệu đang thực thi tại địa chỉ: http://localhost:${Port}`)
);
Dich_vu.on('error', onError);
Dich_vu.on('listening', onListening);
/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
      // named pipe
      return val;
  }

  if (port >= 0) {
      // port number
      return port;
  }

  return false;
}

/**
* Event listener for HTTP server "error" event.
*/

function onError(error) {
  if (error.syscall !== 'listen') {
      throw error;
  }

  var bind = typeof Port === 'string'
      ? 'Pipe ' + Port
      : 'Port ' + Port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
      case 'EACCES':
          console.error(bind + ' requires elevated privileges');
          process.exit(1);
          break;
      case 'EADDRINUSE':
          console.error(bind + ' is already in use');
          process.exit(1);
          break;
      default:
          throw error;
  }
}

/**
* Event listener for HTTP server "listening" event.
*/

function onListening() {
  var addr = Dich_vu.address();
  var bind = typeof addr === 'string'
      ? 'pipe ' + addr
      : 'port ' + addr.port;
  console.log('Listening on ' + bind);
}
