var nodemailer = require('nodemailer');
class XL_GOI_THU_DIEN_TU {
  Goi_Thu_Lien_he(from, to, subject, body) {
    var transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'kimtaetae8@gmail.com', // user gmail
        pass: 'ngochang' // pass gmail
      }
    });

    var mailOptions = {
      from: 'kimtaetae8@gmail.com',
      to: 'kimtaetae8@gmail.com',
      subject: subject,
      html: body
    };
    // Gọi phương thức sendMail -> Promise
    return transporter.sendMail(mailOptions);
  }
}
var Goi_thu = new XL_GOI_THU_DIEN_TU()
module.exports = Goi_thu