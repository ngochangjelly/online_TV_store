//************** Xử lý Lưu trữ ***********
//************** Khai báo đường dẫn Dịch vụ  ***********
var Dia_chi_Dich_vu = "http://localhost:1000"
//var Dia_chi_Dich_vu = "https://tranthingochang-dulieu.herokuapp.com"
//var Dia_chi_Media = "http://localhost:1001"
var Dia_chi_Media = "https://tranthingochang-media.herokuapp.com/"

//************** Các Hàm Xử lý Đọc - Ghi   ***********
function Doc_Danh_sach_Dien_thoai() {
    var Du_lieu = {}
    var Xu_ly_HTTP = new XMLHttpRequest()
    var Tham_so = `Ma_so_Xu_ly=Doc_Danh_sach_Dien_thoai`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}?${Tham_so}`
    Xu_ly_HTTP.open("POST", Dia_chi_Xu_ly, false)
    Xu_ly_HTTP.send("")
    var Chuoi_JSON = Xu_ly_HTTP.responseText
    if (Chuoi_JSON != "")
        Du_lieu = JSON.parse(Chuoi_JSON)
    return Du_lieu
}

// =============================Giỏ hàng===============================
function Ghi_Phieu_Dat_hang(DsPhieu_dat) {
    var Kq = ""
    var Xu_ly_HTTP = new XMLHttpRequest()
    var Tham_so = `Ma_so_Xu_ly=Ghi_Phieu_Dat_hang`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}?${Tham_so}`
    Xu_ly_HTTP.open("POST", Dia_chi_Xu_ly, false)
    var Chuoi_goi = JSON.stringify(DsPhieu_dat)
    Xu_ly_HTTP.send(Chuoi_goi)
    Kq = Xu_ly_HTTP.responseText
    return Kq
}

//************** Các Hàm Xử lý Xuất   ***********

function Tao_The_hien_Cua_hang(Cua_hang, Th_Cha) {
    var Noi_dung_HTML = `
    <img src="${Dia_chi_Media}/${Cua_hang.Ma_so}.png" class="btn" />
        <div class="text-center btn btn-outline-primary">${Cua_hang.Ten}
            <br>
            <small> ${Cua_hang.Dia_chi}</small>
    </div>
    `
    Th_Cha.innerHTML = Noi_dung_HTML
}

function Tao_The_hien_Chi_tiet(Danh_sach_sp, Th_Cha){
    Th_Cha.innerHTML=''
    var The_hien = document.createElement("div")
    // CSS
    The_hien.className = "container-fluid"
    //The_hien.style.cssText = "width:25%;float:left ;object-fit: cover; flex-wrap: wrap;flex: initial; "
    //The_hien.setAttribute("data", id)

    var Noi_dung_HTML = `
    <div class="row">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mt-50">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Furniture</a></li>
                <li class="breadcrumb-item"><a href="#">Chairs</a></li>
                <li class="breadcrumb-item active" aria-current="page"></li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-12 col-lg-7">
        <div class="single_product_thumb">
            <div id="product_details_slider" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li class="active" data-target="#product_details_slider" data-slide-to="0" style="background-image: url(img/product-img/pro-big-1.jpg);">
                    </li>
                    <li data-target="#product_details_slider" data-slide-to="1" style="background-image: url(img/product-img/pro-big-2.jpg);">
                    </li>
                    <li data-target="#product_details_slider" data-slide-to="2" style="background-image: url(img/product-img/pro-big-3.jpg);">
                    </li>
                    <li data-target="#product_details_slider" data-slide-to="3" style="background-image: url(img/product-img/pro-big-4.jpg);">
                    </li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <a class="gallery_img" href="img/product-img/pro-big-1.jpg">
                            <img class="d-block w-100" src="img/product-img/pro-big-1.jpg" alt="First slide">
                        </a>
                    </div>
                    <div class="carousel-item">
                        <a class="gallery_img" href="img/product-img/pro-big-2.jpg">
                            <img class="d-block w-100" src="img/product-img/pro-big-2.jpg" alt="Second slide">
                        </a>
                    </div>
                    <div class="carousel-item">
                        <a class="gallery_img" href="img/product-img/pro-big-3.jpg">
                            <img class="d-block w-100" src="img/product-img/pro-big-3.jpg" alt="Third slide">
                        </a>
                    </div>
                    <div class="carousel-item">
                        <a class="gallery_img" href="img/product-img/pro-big-4.jpg">
                            <img class="d-block w-100" src="img/product-img/pro-big-4.jpg" alt="Fourth slide">
                        </a>
                    </div>
                </div>
            </div>
            

        </div>
    </div>

    

    <div class="col-12 col-lg-5">
        <div class="single_product_desc">
            <!-- Product Meta Data -->
            <div class="product-meta-data">
                <div class="line"></div>
                <p class="product-price">${Danh_sach_sp.Don_gia_Ban}</p>
                <a href="product-details.html">
                    <h6>${Danh_sach_sp.Ten}</h6>
                </a>
                <!-- Ratings & Review -->
                <div class="ratings-review mb-15 d-flex align-items-center justify-content-between">
                    <div class="ratings">
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                    </div>
                    <div class="review">
                        <a href="#">Write A Review</a>
                    </div>
                </div>
                <!-- Avaiable -->
                <p class="avaibility"><i class="fa fa-circle"></i> Number of stocks: ${Danh_sach_sp.So_luong_Ton}</p>
            </div>

            <div class="short_overview my-5">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid quae eveniet culpa officia quidem mollitia impedit iste asperiores nisi reprehenderit consequatur, autem, nostrum pariatur enim?</p>
            </div>

            <!-- Add to Cart Form -->
            <form class="cart clearfix" method="post">
                <div class="cart-btn d-flex mb-50">
                    <p>Qty</p>
                    <div class="quantity">
                        <span class="qty-minus" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) effect.value--;return false;"><i class="fa fa-caret-down" aria-hidden="true"></i></span>
                        <input type="number" class="qty-text" id="qty" step="1" min="1" max="300" name="quantity" value="1">
                        <span class="qty-plus" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty )) effect.value++;return false;"><i class="fa fa-caret-up" aria-hidden="true"></i></span>
                    </div>
                </div>
                <button id="btn_cart_${Danh_sach_sp.Ma_so}" onclick="" type="submit" name="addtocart" value="5" class="btn amado-btn">Add to cart</button>
            </form>

        </div>
    </div>
</div>
    
      `
      //onclick="chitietsp(${Dien_thoai.Ma_so});"
    //onClick="window.location='product-details.html'"
    // <!-- Button trigger modal -->
    // <button type="button" class="btn btn-primary" onclick="Th_Show.click()">
    //     Launch demo modal
    // </button>
    The_hien.innerHTML = `${Noi_dung_HTML}`
    Th_Cha.appendChild(The_hien)
        {
        Th_Gio_hang.innerHTML = `<u>${ds.length}</u>`
        }
    }

//<!--end trang chi tiet sp-->
function chitietsp(id){
    sessionStorage.setItem("Chi_tiet_sp", JSON.stringify(id))
    window.location ="product-details.html";
}

function Tao_The_hien_Danh_sach_Dien_thoai(Danh_sach, Th_Cha) {
    Th_Cha.innerHTML = ""
    Danh_sach.forEach(Dien_thoai => {
        var The_hien = document.createElement("div")
        // CSS
        The_hien.className = "card m-2 border-0"
        The_hien.style.cssText = "width:25%;float:left ;object-fit: cover; flex-wrap: wrap;flex: initial; "
        The_hien.setAttribute("data", Dien_thoai.Ma_so)

        var Noi_dung_HTML = `
        <img class="card-img-top" style="height: 15vw;object-fit: cover;width:100%;"  src="${Dia_chi_Media}/${Dien_thoai.Ma_so}.png" alt="">
        <div class="card-body">
            <h5 class="card-title text-primary"><small>${Dien_thoai.Ten}</small></h5>
            <small class="card-text text-danger">${Number(Dien_thoai.Don_gia_Ban).toLocaleString()} VND </small><br/>
        </div>
            <button id="detail_${Dien_thoai.Ma_so}" type="button" class="btn btn-primary"  >
            More Detail
            </button>
        
          `
        // <!-- Button trigger modal -->
        // <button type="button" class="btn btn-primary" onclick="Th_Show.click()">
        //     Launch demo modal
        // </button>
        The_hien.innerHTML = `${Noi_dung_HTML}`
        Th_Cha.appendChild(The_hien)

        //more detail
       
        The_hien.onclick = () => {
            chitietsp(The_hien.getAttribute('data'))
            //show modal 
            //alert(The_hien.getAttribute('data'))
            showmodal(The_hien.getAttribute('data'))
            //console(The_hien.getAttribute("data"))
            The_hien.classList.toggle("CHON")
            // Lưu Session HTML5

            var ds = []
            if (sessionStorage.getItem("Danh_sach_Chon") != undefined) {
                ds = JSON.parse(sessionStorage.getItem("Danh_sach_Chon"))
            }

            var vt = ds.indexOf(Dien_thoai.Ma_so)
            if (vt == -1) {
                ds.push(Dien_thoai.Ma_so)
            } else {
                ds.splice(vt, 1)
            }

            if (ds.length > 0) {
                sessionStorage.setItem("Danh_sach_Chon", JSON.stringify(ds))
            } else {
                sessionStorage.removeItem("Danh_sach_Chon")
            }

            Th_Gio_hang.innerHTML = `<u>${ds.length}</u>`
        }
    })
}
// Giỏ hàng
// function Xuat_Dien_thoai_Mua(Danh_sach_Mua, Th_Cha) {
//     Th_Cha.innerHTML = ""
//     var noi_dung_HTML = ``
//     Danh_sach_Mua.forEach(Dien_thoai_Mua => {
//         noi_dung_HTML += `
//     <tr>
//         <td scope="row">
//             <img src=http://localhost:1001/${Dien_thoai_Mua.Ma_so}.png style="width:80px" />
//         </td >
//         <td>${Dien_thoai_Mua.Ten}</td>
//         <td>${Dien_thoai_Mua.Nhom_Tivi.Ma_so}</td>
//         <td>
//             <input type="number" min="1" max="10" id="Th_So_luong_${Dien_thoai_Mua.Ma_so}" value="1" class="text-right" />
//         </td>
//         <td>${Number(Dien_thoai_Mua.Don_gia_Ban).toLocaleString()} VND</td>
//     </tr >
//     `
//     })
//     Th_Cha.innerHTML = noi_dung_HTML
// }
function Xuat_Dien_thoai_Mua(Danh_sach_Mua, Th_Cha) {
    Th_Cha.innerHTML = ""
    var noi_dung_HTML = ``
    Danh_sach_Mua.forEach(Dien_thoai_Mua => {
        noi_dung_HTML += `
        <td class="cart_product_img">
                <a href="#"><img src=https://tranthingochang-media.herokuapp.com/${Dien_thoai_Mua.Ma_so}.png alt="Product"></a>
            </td>
            <td class="cart_product_desc">
                <h5>${Dien_thoai_Mua.Ten}</h5>
            </td>
            <td class="price">
                <span>${Number(Dien_thoai_Mua.Don_gia_Ban).toLocaleString()} VND</span>
            </td>
            <td class="qty">
                <div class="qty-btn d-flex">
                    <p>Qty</p>
                    <div class="quantity">
                        <span class="qty-minus" onclick="var effect = document.getElementById('Th_So_luong_${Dien_thoai_Mua.Ma_so}'); var qty = effect.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) effect.value--;return false;"><i class="fa fa-minus" aria-hidden="true"></i></span>
                        <input type="number" class="qty-text" id="Th_So_luong_${Dien_thoai_Mua.Ma_so}" step="1" min="1" max="300" name="quantity" value="1">
                        <span class="qty-plus" onclick="var effect = document.getElementById('Th_So_luong_${Dien_thoai_Mua.Ma_so}'); var qty = effect.value; if( !isNaN( qty )) effect.value++;return false;"><i class="fa fa-plus" aria-hidden="true"></i></span>
                    </div>
                </div>
            </td>
        </tr>        
        <!--original ver -->
        <!--
    <tr>
        <td scope="row">
            <img src=https://tranthingochang-media.herokuapp.com/${Dien_thoai_Mua.Ma_so}.png style="width:80px" />
        </td >
        <td>${Dien_thoai_Mua.Ten}</td>
        <td>${Dien_thoai_Mua.Nhom_Tivi.Ma_so}</td>
        <td>
            <input type="number" min="1" max="10" id="Th_So_luong_${Dien_thoai_Mua.Ma_so}" value="1" class="text-right" />
        </td>
        <td>${Number(Dien_thoai_Mua.Don_gia_Ban).toLocaleString()} VND</td>
    </tr > 
    -->
    `
    })
    Th_Cha.innerHTML = noi_dung_HTML
}

function Xuat_Thong_tin_Dat_hang_Thanh_cong(Th_Cha, Ds_Phieu_Dat) {
    var noi_dung_HTML = `
    <table class="table" >
            <thead>
                <tr>
                    <th>Product </th>
                    <th>Name </th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>
            </thead>
    `
    var Tong = 0
    Ds_Phieu_Dat.forEach(Khach => {
        noi_dung_HTML += `
        <tbody>
        <tr>
            <td colspan="30">
                <img src=https://tranthingochang-media.herokuapp.com/${Khach.Dien_thoai.Ma_so}.png style="width:80px" />
            </td >
            <td>${Khach.Dien_thoai.Ten}</td>
            <!--
            <td>${Khach.Dien_thoai.Nhom_Tivi.Ma_so}</td>
            -->
            <td>
                ${Khach.Phieu_Dat.So_luong}
            </td>
            <td>${Number(Khach.Dien_thoai.Don_gia_Ban).toLocaleString()} VND</td>
        </tr >
        `
        Tong += Khach.Phieu_Dat.So_luong * Khach.Dien_thoai.Don_gia_Ban
    })
    noi_dung_HTML += `
    <tr>
        <td colspan="120" class="text-danger"><strong>TOTAL:${Number(Tong).toLocaleString()} VND</strong></td>
    </tr>
    <tr >
       <h6 class="text-info">Hello ${Ds_Phieu_Dat[0].Phieu_Dat.Khach_hang.Ho_ten}<br>
       Your delivery address: ${Ds_Phieu_Dat[0].Phieu_Dat.Khach_hang.Dia_chi}<br>
        Phone: ${Ds_Phieu_Dat[0].Phieu_Dat.Khach_hang.Dien_thoai}<br>
        Email: ${Ds_Phieu_Dat[0].Phieu_Dat.Khach_hang.Email}
        </h6>     
    </tr>
    <tr>
        <td colspan="30"><button class="btn amado-btn w-30" onclick="window.location='MH_Danh_sach_Dien_thoai.html'">Confirm Order</button></td>
    </tr>    
    
    </tbody>
    </table>
    `
    Th_Cha.innerHTML = noi_dung_HTML
}
//contact via mail
function Khach_hang_Lien_he(noi_dung) {
    var Kq = ""
    var Xu_ly_HTTP = new XMLHttpRequest()
    var Tham_so = `Ma_so_Xu_ly=Goi_thu_Lien_he`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}?${Tham_so}`
    Xu_ly_HTTP.open("POST", Dia_chi_Xu_ly, false)
    var Chuoi_goi = noi_dung
    Xu_ly_HTTP.send(Chuoi_goi)
    Kq = Xu_ly_HTTP.responseText
    return Kq
}
// create ckeditor form and send via email
// function Send_review_via_email(Th_Cha){
//     Th_Show.click()
//     modelTitleId="Feel free to talk to us"
//     var The_hien = document.createElement("div")
//     The_hien.setAttribute('class','container-fluid')
//         var Noi_dung_HTML = `
//             <span class="input-label row">Your name: </span>
//             <input id='Th_name' type="text"/>
//             <span class="input-label row">Your e-mail: </span>
//             <input id='Th_mail' type="email"/>
//             <span class="input-label row">Your comment: </span>
//             <textarea id='Th_noi_dung_gui'  class="form-control " aria-label="With textarea"></textarea>
//             <button id='btn_submit' >Submit</button>
//           `   
//           //
               
//           btn_submit = (Th_name,Th_mail) =>{
//             var ho_ten=Th_name.value
//             var email=Th_mail.value
//             var tieu_de='Customer inquiry'
//             var noi_dung=Th_noi_dung_gui.value
//             //var noi_dung = CKEDITOR.instances.Th_Noi_dung.getData()
//             var html=`<h4>Họ tên:${ho_ten}</h4>`
//             html+=`email:${email}`
//             html+=`<h5>${tieu_de}</h4>`
//             html+=noi_dung
//             //console.log(html) 
//             var Kq=Khach_hang_Lien_he(html)
//             if(Kq=="OK"){
//                console.log(`Cám ơn bạn đã gởi mail. Chúng tôi sẽ sớm trả lời thư của bạn`)
//             }else{
//                 console.log('request failed')
//             }
//           }
        
//           //
//         The_hien.innerHTML = `${Noi_dung_HTML}`
//         Th_Cha.appendChild(The_hien)
// }


